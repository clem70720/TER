import numpy as np
import pandas as pad
import time
from keras.utils import to_categorical
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten, Conv2D, MaxPool2D
from keras.losses import SparseCategoricalCrossentropy
from keras.datasets import fashion_mnist

# get the start time
st = time.process_time()

(X_train,y_train),(X_test,y_test) = fashion_mnist.load_data()

X_train = (X_train/255).reshape(X_train.shape[0],28,28,1)
X_test = (X_test/255).reshape(X_test.shape[0],28,28,1)

y_train = to_categorical(y_train,10)
y_test = to_categorical(y_test,10)

model = Sequential()

model.add(Conv2D(32,(3,3),activation='relu', input_shape=(28,28,1)))
model.add(Conv2D(32,(3,3),activation='relu'))
model.add(MaxPool2D(pool_size=(2,2)))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(128,activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

model.fit(X_train,y_train,batch_size=100,epochs=10, verbose=1)

score = model.evaluate(X_test,y_test,verbose=0)

print("Pourcentage de bien classées:", score[1])

# get the end time
et = time.process_time()
# get execution time
res = et - st
print('CPU Execution time:', res, 'seconds')